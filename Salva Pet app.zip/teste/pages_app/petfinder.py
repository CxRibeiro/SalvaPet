"""Animais Perdidos — mapa interativo de animais perdidos e encontrados."""
from __future__ import annotations

import html

import folium
import pandas as pd
import streamlit as st
from streamlit_folium import st_folium

from services.animals import listar_animais, listar_organizacoes, resolver_foto
from utils.constants import (
    MAPA_CENTRO,
    MAPA_ZOOM,
    STATUS_CORES,
    STATUS_ENCONTRADO,
    STATUS_LABELS,
    STATUS_PERDIDO,
)


def _txt(valor, padrao: str = "") -> str:
    """Converte qualquer valor em texto seguro para HTML.

    Trata None e o NaN (float) que o pandas usa para células vazias —
    ambos viram o texto padrão em vez de quebrar o html.escape().
    """
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return padrao
    return html.escape(str(valor))


def _popup_html(animal: dict) -> str:
    nome = _txt(animal.get("nome"), "Sem nome")
    especie = _txt(animal.get("especie"))
    descricao = _txt(animal.get("descricao"))
    status = STATUS_LABELS.get(animal.get("status"), _txt(animal.get("status")))
    data = _txt(animal.get("data_evento"))
    contato = _txt(animal.get("contato_nome"))
    tel = _txt(animal.get("contato_tel"))

    foto = resolver_foto(animal)
    img_tag = (
        f'<img src="{html.escape(foto)}" width="180" style="border-radius:6px;">'
        if foto and str(foto).startswith("http")
        else ""
    )

    # Para perdidos, lista as ONGs/petshops que podem ajudar no resgate.
    resgate_html = ""
    if animal.get("status") == STATUS_PERDIDO:
        orgs = listar_organizacoes(_txt(animal.get("cidade"), "") or None)
        if not orgs.empty:
            itens = "".join(
                f"<li>{_txt(o.get('nome'))} — {_txt(o.get('telefone'))}<br>"
                f"<small>{_txt(o.get('endereco'))}</small></li>"
                for _, o in orgs.head(3).iterrows()
            )
            resgate_html = (
                "<hr style='margin:4px 0;'>"
                "<b>Resgate (ONGs/petshops):</b>"
                f"<ul style='padding-left:16px; margin:4px 0;'>{itens}</ul>"
            )

    return f"""
    <div style="font-family:sans-serif; max-width:220px;">
        {img_tag}
        <h4 style="margin:4px 0;">{nome} <small>({especie})</small></h4>
        <b>{status}</b><br>
        <small>{data}</small>
        <p style="margin:4px 0;">{descricao}</p>
        <small>Contato: {contato} {tel}</small>
        {resgate_html}
    </div>
    """


def render() -> None:
    st.header("🗺️ Animais Perdidos — perdidos e encontrados")
    st.caption(
        "Mapa com registros de animais perdidos (vermelho) e encontrados (laranja)."
    )

    df = listar_animais(status=[STATUS_PERDIDO, STATUS_ENCONTRADO])

    # Filtro opcional: começa em "Todos", então o mapa já aparece sem exigir
    # que o usuário selecione nada previamente.
    TODOS = "todos"
    opcoes = [TODOS, STATUS_PERDIDO, STATUS_ENCONTRADO]
    rotulos = {
        TODOS: "Todos",
        STATUS_PERDIDO: STATUS_LABELS[STATUS_PERDIDO],
        STATUS_ENCONTRADO: STATUS_LABELS[STATUS_ENCONTRADO],
    }
    escolha = st.radio(
        "Mostrar",
        opcoes,
        index=0,
        horizontal=True,
        format_func=lambda s: rotulos[s],
    )

    if escolha != TODOS:
        df = df[df["status"] == escolha]

    if df.empty:
        if escolha == STATUS_PERDIDO:
            st.info("Nenhum animal perdido registrado por enquanto.")
        elif escolha == STATUS_ENCONTRADO:
            st.info("Nenhum animal encontrado registrado por enquanto.")
        else:
            st.info("Nenhum registro de animal perdido ou encontrado por enquanto.")
        return

    mapa = folium.Map(location=MAPA_CENTRO, zoom_start=MAPA_ZOOM, control_scale=True)

    marcadores = 0
    for _, row in df.iterrows():
        if pd.isna(row.get("latitude")) or pd.isna(row.get("longitude")):
            continue
        animal = row.to_dict()
        folium.Marker(
            location=[float(row["latitude"]), float(row["longitude"])],
            popup=folium.Popup(_popup_html(animal), max_width=250),
            tooltip=f"{_txt(animal.get('nome'), 'Sem nome')} — {STATUS_LABELS.get(row['status'])}",
            icon=folium.Icon(
                color=STATUS_CORES.get(row["status"], "gray"),
                icon="paw",
                prefix="fa",
            ),
        ).add_to(mapa)
        marcadores += 1

    st_folium(mapa, width=1100, height=500, returned_objects=[])
    st.caption(f"{marcadores} animal(is) no mapa.")

    st.subheader("Registros")
    for _, row in df.iterrows():
        animal = row.to_dict()
        with st.expander(
            f"{_txt(animal.get('nome'), 'Sem nome')} — "
            f"{STATUS_LABELS.get(row['status'])} ({_txt(animal.get('cidade'), '-')})"
        ):
            colf, colt = st.columns([1, 2])
            with colf:
                foto = resolver_foto(animal)
                if foto:
                    st.image(foto, use_container_width=True)
            with colt:
                st.write(f"**Espécie:** {_txt(animal.get('especie'), '-')}")
                st.write(
                    f"**Porte:** {_txt(animal.get('porte'), '-')} | "
                    f"**Sexo:** {_txt(animal.get('sexo'), '-')}"
                )
                st.write(f"**Cor:** {_txt(animal.get('cor'), '-')}")
                st.write(f"**Data:** {_txt(animal.get('data_evento'), '-')}")
                st.write(f"**Descrição:** {_txt(animal.get('descricao'), '-')}")
                contato = _txt(animal.get("contato_nome"))
                tel = _txt(animal.get("contato_tel"))
                if contato or tel:
                    st.write(f"**Contato:** {contato or ''} {tel or ''}")

            # Para animais perdidos: contatos de ONGs/petshops que podem
            # ajudar a buscar o animal (prioriza a mesma cidade).
            if row["status"] == STATUS_PERDIDO:
                _bloco_resgate(animal.get("cidade"))


def _bloco_resgate(cidade) -> None:
    orgs = listar_organizacoes(_txt(cidade, "") or None)
    if orgs.empty:
        return
    st.markdown("**🏥 ONGs / petshops para resgate:**")
    for _, o in orgs.iterrows():
        org = o.to_dict()
        st.write(
            f"- **{_txt(org.get('nome'))}** · 📞 {_txt(org.get('telefone'))} · "
            f"📍 {_txt(org.get('endereco'))} ({_txt(org.get('cidade'))})"
        )
