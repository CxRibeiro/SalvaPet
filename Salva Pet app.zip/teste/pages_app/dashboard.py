"""Dashboard — análise de dados (Pandas) e gráficos (Plotly)."""
from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from services.animals import listar_animais, metricas_gerais
from utils.constants import STATUS_LABELS


def render() -> None:
    st.header("📊 Dashboard & Análise")
    st.caption("Visão geral dos registros, com análise em Pandas e gráficos em Plotly.")

    m = metricas_gerais()
    c1, c2, c3, c4, c5, c6 = st.columns(6)
    c1.metric("Total", m["total"])
    c2.metric("Perdidos", m["perdidos"])
    c3.metric("Encontrados", m["encontrados"])
    c4.metric("Para adoção", m["para_adocao"])
    c5.metric("Adotados", m["adotados"])
    c6.metric("Reunidos", m["reunidos"])

    df = listar_animais()
    if df.empty:
        st.info("Ainda não há dados para análise.")
        return

    st.divider()

    col1, col2 = st.columns(2)

    # Gráfico 1: distribuição por status.
    with col1:
        st.subheader("Registros por status")
        por_status = (
            df["status"].map(STATUS_LABELS).value_counts().reset_index()
        )
        por_status.columns = ["Status", "Quantidade"]
        fig = px.pie(por_status, names="Status", values="Quantidade", hole=0.4)
        st.plotly_chart(fig, use_container_width=True)

    # Gráfico 2: distribuição por espécie.
    with col2:
        st.subheader("Registros por espécie")
        por_especie = df["especie"].value_counts().reset_index()
        por_especie.columns = ["Espécie", "Quantidade"]
        fig2 = px.bar(
            por_especie, x="Espécie", y="Quantidade", color="Espécie", text="Quantidade"
        )
        st.plotly_chart(fig2, use_container_width=True)

    col3, col4 = st.columns(2)

    # Gráfico 3: registros por cidade.
    with col3:
        st.subheader("Registros por cidade")
        por_cidade = df["cidade"].fillna("Não informado").value_counts().reset_index()
        por_cidade.columns = ["Cidade", "Quantidade"]
        fig3 = px.bar(por_cidade, x="Quantidade", y="Cidade", orientation="h")
        st.plotly_chart(fig3, use_container_width=True)

    # Gráfico 4: linha do tempo de eventos.
    with col4:
        st.subheader("Eventos ao longo do tempo")
        tmp = df.copy()
        tmp["data_evento"] = pd.to_datetime(tmp["data_evento"], errors="coerce")
        linha = (
            tmp.dropna(subset=["data_evento"])
            .groupby([tmp["data_evento"].dt.date, "status"])
            .size()
            .reset_index(name="Quantidade")
        )
        if linha.empty:
            st.info("Sem datas suficientes para a linha do tempo.")
        else:
            linha["status"] = linha["status"].map(STATUS_LABELS)
            linha.columns = ["Data", "Status", "Quantidade"]
            fig4 = px.line(linha, x="Data", y="Quantidade", color="Status", markers=True)
            st.plotly_chart(fig4, use_container_width=True)

    st.divider()
    st.subheader("Tabela de dados")

    # Seleção de colunas mais relevantes para a análise tabular.
    colunas = [
        "id", "nome", "especie", "raca", "porte", "sexo", "idade_anos",
        "cor", "status", "cidade", "data_evento", "abrigo_nome",
    ]
    colunas = [c for c in colunas if c in df.columns]
    tabela = df[colunas].copy()
    tabela["status"] = tabela["status"].map(STATUS_LABELS)
    st.dataframe(tabela, use_container_width=True, hide_index=True)

    # Download da análise em CSV.
    csv = tabela.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Baixar dados (CSV)",
        data=csv,
        file_name="animais.csv",
        mime="text/csv",
    )
