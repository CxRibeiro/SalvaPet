"""Tela de cadastro de animais (perdido, encontrado ou para adoção)."""
from __future__ import annotations

from datetime import date

import streamlit as st

from services.animals import cadastrar_animal, listar_abrigos, salvar_foto
from utils.constants import (
    ESPECIES,
    MAPA_CENTRO,
    PORTES,
    SEXOS,
    STATUS_ENCONTRADO,
    STATUS_LABELS,
    STATUS_PARA_ADOCAO,
    STATUS_PERDIDO,
)


def render() -> None:
    st.header("📝 Cadastro de animais")
    st.caption(
        "Cadastre um animal perdido, encontrado ou disponível para adoção. "
        "Cada registro recebe um status próprio."
    )

    # Status fora do form para que os campos condicionais reajam na hora.
    status_opcoes = [STATUS_PERDIDO, STATUS_ENCONTRADO, STATUS_PARA_ADOCAO]
    status = st.selectbox(
        "Tipo de registro",
        status_opcoes,
        format_func=lambda s: STATUS_LABELS[s],
    )

    abrigos_df = listar_abrigos()

    with st.form("form_cadastro", clear_on_submit=True):
        col1, col2 = st.columns(2)
        with col1:
            nome = st.text_input("Nome do animal (se souber)")
            especie = st.selectbox("Espécie", ESPECIES)
            raca = st.text_input("Raça", value="SRD")
            porte = st.selectbox("Porte", PORTES)
            sexo = st.selectbox("Sexo", SEXOS)
        with col2:
            idade = st.number_input("Idade (anos)", min_value=0.0, max_value=30.0, step=0.5)
            cor = st.text_input("Cor predominante")
            cidade = st.text_input("Cidade", value="São Paulo")
            data_evento = st.date_input("Data do evento", value=date.today())

        descricao = st.text_area(
            "Descrição",
            placeholder="Características, comportamento, onde foi visto pela última vez...",
        )

        st.markdown("**Localização aproximada** (usada no mapa de Animais Perdidos)")
        colm1, colm2 = st.columns(2)
        with colm1:
            latitude = st.number_input(
                "Latitude", value=float(MAPA_CENTRO[0]), format="%.6f"
            )
        with colm2:
            longitude = st.number_input(
                "Longitude", value=float(MAPA_CENTRO[1]), format="%.6f"
            )

        st.markdown("**Foto do animal**")
        foto_arquivo = st.file_uploader(
            "Enviar foto (opcional)",
            type=["png", "jpg", "jpeg", "gif", "webp"],
        )
        foto_url = st.text_input(
            "...ou cole o link de uma foto (opcional)",
            placeholder="https://...",
        )

        # Campos condicionais por status.
        contato_nome = contato_tel = tutor_nome = tutor_tel = ""
        abrigo_id = None

        if status in (STATUS_PERDIDO, STATUS_ENCONTRADO):
            st.markdown("**Contato de quem registrou**")
            colc1, colc2 = st.columns(2)
            with colc1:
                contato_nome = st.text_input("Nome do contato")
            with colc2:
                contato_tel = st.text_input("Telefone do contato")

        if status == STATUS_PERDIDO:
            st.markdown("**Dados do tutor**")
            colt1, colt2 = st.columns(2)
            with colt1:
                tutor_nome = st.text_input("Nome do tutor")
            with colt2:
                tutor_tel = st.text_input("Telefone do tutor")

        if status == STATUS_PARA_ADOCAO:
            if abrigos_df.empty:
                st.warning("Cadastre um abrigo antes de disponibilizar para adoção.")
            else:
                abrigo_label = st.selectbox(
                    "Abrigo/ONG responsável",
                    abrigos_df["id"].tolist(),
                    format_func=lambda i: abrigos_df.loc[
                        abrigos_df["id"] == i, "nome"
                    ].iloc[0],
                )
                abrigo_id = int(abrigo_label)

        enviado = st.form_submit_button("Cadastrar animal", type="primary")

    if enviado:
        if status == STATUS_PARA_ADOCAO and abrigo_id is None:
            st.error("É necessário selecionar um abrigo responsável.")
            return

        caminho_foto = salvar_foto(foto_arquivo)

        dados = {
            "nome": nome or None,
            "especie": especie,
            "raca": raca or None,
            "porte": porte,
            "sexo": sexo,
            "idade_anos": idade or None,
            "cor": cor or None,
            "descricao": descricao or None,
            "status": status,
            "cidade": cidade or None,
            "latitude": latitude,
            "longitude": longitude,
            "data_evento": data_evento.isoformat(),
            "foto_url": foto_url or None,
            "foto_path": caminho_foto,
            "contato_nome": contato_nome or None,
            "contato_tel": contato_tel or None,
            "abrigo_id": abrigo_id,
            "tutor_nome": tutor_nome or None,
            "tutor_tel": tutor_tel or None,
        }
        novo_id = cadastrar_animal(dados)
        st.success(f"Animal cadastrado com sucesso! (ID #{novo_id})")
        st.balloons()
