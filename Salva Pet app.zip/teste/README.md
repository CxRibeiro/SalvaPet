# 🐾 PetConnect

App que integra dois sistemas para o bem-estar animal:

- **PetFinder** — mapa interativo de animais **perdidos** e **encontrados** (Folium).
- **AdotaPet** — catálogo de animais disponíveis para **adoção**.
- **Integração** (o diferencial) — ao registrar um animal encontrado, o app
  busca o possível tutor; se não houver tutor e o animal estiver disponível,
  uma ONG pode encaminhá-lo para adoção responsável.

## Tecnologias

| Tecnologia | Uso |
|-----------|-----|
| Python | Linguagem principal |
| Streamlit | Interface web |
| Folium + streamlit-folium | Mapa dos animais |
| Pandas | Análise de dados |
| Plotly | Gráficos do dashboard |
| SQLite | Banco de dados |

## Estrutura do projeto

```
teste/
├── app.py                 # entrada do Streamlit + navegação
├── requirements.txt
├── petconnect.db          # banco SQLite (criado na 1ª execução)
├── uploads/               # fotos enviadas pelos usuários (criada ao subir foto)
├── database/
│   └── db.py              # conexão, schema e dados de exemplo
├── services/
│   └── animals.py         # CRUD, upload de fotos e regras de integração
├── pages_app/
│   ├── petfinder.py       # mapa de perdidos/encontrados
│   ├── adotapet.py        # catálogo de adoção
│   ├── cadastro.py        # formulário de cadastro (com upload de foto)
│   ├── integracao.py      # fluxo encontrado -> tutor -> adoção
│   └── dashboard.py       # métricas e gráficos
└── utils/
    └── constants.py       # status, espécies, portes, etc.
```

## Pré-requisito: instalar o Python

> ⚠️ Este computador **não tem o Python instalado** (só o atalho da Microsoft Store).
> É preciso instalar antes de rodar.

1. Baixe em <https://www.python.org/downloads/> (versão 3.10 ou superior).
2. No instalador, marque **"Add Python to PATH"** antes de clicar em *Install*.
3. Feche e reabra o terminal.
4. Confirme a instalação:
   ```powershell
   python --version
   ```

## Como rodar

No terminal, dentro da pasta do projeto:

```powershell
# 1. (opcional, recomendado) criar um ambiente virtual
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# 2. instalar as dependências
pip install -r requirements.txt

# 3. iniciar o app
streamlit run app.py
```

O navegador abre automaticamente em `http://localhost:8501`.
Na primeira execução o banco `petconnect.db` é criado com alguns animais de exemplo.

## Fluxo de uso

1. **Cadastrar animal** — registre um perdido, encontrado ou para adoção
   (pode enviar uma foto do dispositivo ou colar um link).
2. **PetFinder** — veja os perdidos/encontrados no mapa.
3. **Integração** — selecione um animal encontrado, verifique possíveis
   tutores e, se não houver, encaminhe para adoção.
4. **AdotaPet** — veja os disponíveis para adoção e registre uma adoção.
5. **Dashboard** — acompanhe métricas e gráficos.
